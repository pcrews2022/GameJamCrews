"use client";

import { useEffect, useMemo, useState } from "react";
import {
  ArrowUpRight,
  Banknote,
  ChevronRight,
  CircleDollarSign,
  Crown,
  Flame,
  RotateCcw,
  ShieldCheck,
  Trophy,
} from "lucide-react";
import { toast } from "sonner";
import { Progress } from "@/components/ui/progress";
import { Toaster } from "@/components/ui/sonner";

type Pick = {
  id: string;
  label: string;
  sub: string;
  odds: number;
};

type Match = {
  id: string;
  league: string;
  clock: string;
  away: string;
  awayCode: string;
  home: string;
  homeCode: string;
  picks: Pick[];
};

type Bet = {
  id: string;
  matchId: string;
  matchup: string;
  pick: Pick;
  stake: number;
};

type Result = Bet & {
  won: boolean;
  payout: number;
};

type SavedGame = {
  bankroll: number;
  highScore: number;
  day: number;
  streak: number;
  bestStreak: number;
  placed: number;
  won: number;
  pending: Bet[];
  results: Result[];
};

const STARTING_BANKROLL = 25;
const PENTHOUSE_GOAL = 15000;
const SAVE_KEY = "odds-up-save-v1";

const tiers = [
  { name: "Street Bench", threshold: 0, icon: "01" },
  { name: "Couch Surfing", threshold: 250, icon: "02" },
  { name: "Studio Key", threshold: 800, icon: "03" },
  { name: "Downtown Suite", threshold: 2500, icon: "04" },
  { name: "High Roller", threshold: 7500, icon: "05" },
  { name: "Penthouse", threshold: PENTHOUSE_GOAL, icon: "06" },
];

const slates: Match[][] = [
  [
    {
      id: "mia-orl",
      league: "PRO BASKETBALL",
      clock: "7:10 PM",
      away: "Miami Waves",
      awayCode: "MIA",
      home: "Orlando Solar",
      homeCode: "ORL",
      picks: [
        { id: "mia-spread", label: "MIA +3.5", sub: "Spread", odds: 1.91 },
        { id: "orl-ml", label: "ORL ML", sub: "Moneyline", odds: 1.72 },
        { id: "over", label: "Over 218.5", sub: "Total", odds: 1.95 },
      ],
    },
    {
      id: "tam-jax",
      league: "PRO FOOTBALL",
      clock: "8:20 PM",
      away: "Tampa Tritons",
      awayCode: "TAM",
      home: "Jacksonville Kings",
      homeCode: "JAX",
      picks: [
        { id: "tam-ml", label: "TAM ML", sub: "Moneyline", odds: 1.58 },
        { id: "jax-spread", label: "JAX +6.5", sub: "Spread", odds: 1.92 },
        { id: "under", label: "Under 45.5", sub: "Total", odds: 1.88 },
      ],
    },
    {
      id: "atl-nash",
      league: "PRO SOCCER",
      clock: "9:00 PM",
      away: "Atlanta Gold",
      awayCode: "ATL",
      home: "Nashville Notes",
      homeCode: "NSH",
      picks: [
        { id: "atl-win", label: "ATL Win", sub: "Full time", odds: 2.3 },
        { id: "draw", label: "Draw", sub: "Full time", odds: 3.15 },
        { id: "btts", label: "Both Score", sub: "Yes", odds: 1.74 },
      ],
    },
  ],
  [
    {
      id: "bos-ny",
      league: "PRO BASEBALL",
      clock: "6:40 PM",
      away: "Boston Harbor",
      awayCode: "BOS",
      home: "New York Empire",
      homeCode: "NYE",
      picks: [
        { id: "bos-ml", label: "BOS ML", sub: "Moneyline", odds: 2.05 },
        { id: "nye-run", label: "NYE -1.5", sub: "Run line", odds: 2.18 },
        { id: "over", label: "Over 8.5", sub: "Total", odds: 1.87 },
      ],
    },
    {
      id: "dal-phx",
      league: "PRO BASKETBALL",
      clock: "8:10 PM",
      away: "Dallas Outlaws",
      awayCode: "DAL",
      home: "Phoenix Heat",
      homeCode: "PHX",
      picks: [
        { id: "dal-spread", label: "DAL +1.5", sub: "Spread", odds: 1.9 },
        { id: "phx-ml", label: "PHX ML", sub: "Moneyline", odds: 1.8 },
        { id: "under", label: "Under 226.5", sub: "Total", odds: 1.94 },
      ],
    },
    {
      id: "sea-den",
      league: "PRO FOOTBALL",
      clock: "9:15 PM",
      away: "Seattle Surge",
      awayCode: "SEA",
      home: "Denver Peaks",
      homeCode: "DEN",
      picks: [
        { id: "sea-spread", label: "SEA +4.5", sub: "Spread", odds: 1.93 },
        { id: "den-ml", label: "DEN ML", sub: "Moneyline", odds: 1.62 },
        { id: "over", label: "Over 42.5", sub: "Total", odds: 1.9 },
      ],
    },
  ],
  [
    {
      id: "la-sf",
      league: "PRO BASEBALL",
      clock: "4:10 PM",
      away: "Los Angeles Stars",
      awayCode: "LAS",
      home: "San Francisco Fog",
      homeCode: "SFF",
      picks: [
        { id: "la-ml", label: "LAS ML", sub: "Moneyline", odds: 1.68 },
        { id: "sf-run", label: "SFF +1.5", sub: "Run line", odds: 1.75 },
        { id: "under", label: "Under 7.5", sub: "Total", odds: 2.04 },
      ],
    },
    {
      id: "aus-cha",
      league: "PRO SOCCER",
      clock: "7:30 PM",
      away: "Austin Verde",
      awayCode: "AUS",
      home: "Charlotte Crown",
      homeCode: "CLT",
      picks: [
        { id: "aus-win", label: "AUS Win", sub: "Full time", odds: 2.42 },
        { id: "clt-dnb", label: "CLT DNB", sub: "Draw no bet", odds: 1.76 },
        { id: "over", label: "Over 2.5", sub: "Goals", odds: 1.84 },
      ],
    },
    {
      id: "chi-det",
      league: "PRO HOCKEY",
      clock: "8:00 PM",
      away: "Chicago Freeze",
      awayCode: "CHI",
      home: "Detroit Motors",
      homeCode: "DET",
      picks: [
        { id: "chi-puck", label: "CHI +1.5", sub: "Puck line", odds: 1.65 },
        { id: "det-ml", label: "DET ML", sub: "Moneyline", odds: 1.92 },
        { id: "over", label: "Over 6.0", sub: "Total", odds: 2.02 },
      ],
    },
  ],
];

const money = (value: number) =>
  new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    maximumFractionDigits: 0,
  }).format(value);

const decimalToAmerican = (odds: number) =>
  odds >= 2 ? `+${Math.round((odds - 1) * 100)}` : `${Math.round(-100 / (odds - 1))}`;

function getTierIndex(bankroll: number) {
  return Math.max(
    0,
    tiers.reduce((current, tier, index) => (bankroll >= tier.threshold ? index : current), 0),
  );
}

export default function Home() {
  const [bankroll, setBankroll] = useState(STARTING_BANKROLL);
  const [highScore, setHighScore] = useState(STARTING_BANKROLL);
  const [day, setDay] = useState(1);
  const [streak, setStreak] = useState(0);
  const [bestStreak, setBestStreak] = useState(0);
  const [placed, setPlaced] = useState(0);
  const [won, setWon] = useState(0);
  const [selected, setSelected] = useState<{ match: Match; pick: Pick } | null>(null);
  const [stake, setStake] = useState(5);
  const [pending, setPending] = useState<Bet[]>([]);
  const [results, setResults] = useState<Result[]>([]);
  const [settling, setSettling] = useState(false);
  const [loaded, setLoaded] = useState(false);
  const [championDismissed, setChampionDismissed] = useState(false);

  const matches = slates[(day - 1) % slates.length];
  const tierIndex = getTierIndex(bankroll);
  const tier = tiers[tierIndex];
  const nextTier = tiers[Math.min(tierIndex + 1, tiers.length - 1)];
  const isChampion = bankroll >= PENTHOUSE_GOAL;
  const amountToNext = Math.max(0, nextTier.threshold - bankroll);
  const tierProgress = isChampion
    ? 100
    : Math.max(
        0,
        Math.min(
          100,
          ((bankroll - tier.threshold) / (nextTier.threshold - tier.threshold)) * 100,
        ),
      );

  const possibleReturn = selected ? Math.round(stake * selected.pick.odds * 100) / 100 : 0;
  const winRate = placed ? Math.round((won / placed) * 100) : 0;

  useEffect(() => {
    try {
      const saved = localStorage.getItem(SAVE_KEY);
      if (saved) {
        const game = JSON.parse(saved) as SavedGame;
        setBankroll(game.bankroll);
        setHighScore(game.highScore);
        setDay(game.day);
        setStreak(game.streak);
        setBestStreak(game.bestStreak);
        setPlaced(game.placed);
        setWon(game.won);
        setPending(game.pending ?? []);
        setResults(game.results ?? []);
      }
    } catch {
      localStorage.removeItem(SAVE_KEY);
    }
    setLoaded(true);
  }, []);

  useEffect(() => {
    if (!loaded) return;
    const game: SavedGame = { bankroll, highScore, day, streak, bestStreak, placed, won, pending, results };
    localStorage.setItem(SAVE_KEY, JSON.stringify(game));
  }, [bankroll, highScore, day, streak, bestStreak, placed, won, pending, results, loaded]);

  const occupiedMatchIds = useMemo(() => new Set(pending.map((bet) => bet.matchId)), [pending]);

  function choosePick(match: Match, pick: Pick) {
    if (occupiedMatchIds.has(match.id)) return;
    setSelected({ match, pick });
    setStake(Math.max(1, Math.min(stake, Math.floor(bankroll))));
  }

  function placeBet() {
    if (!selected || bankroll < 1) return;
    const requestedStake = Number.isFinite(stake) ? stake : 1;
    const cleanStake = Math.max(1, Math.min(Math.floor(requestedStake), Math.floor(bankroll)));
    if (cleanStake > bankroll) return;

    const newBet: Bet = {
      id: `${selected.match.id}-${selected.pick.id}-${Date.now()}`,
      matchId: selected.match.id,
      matchup: `${selected.match.awayCode} @ ${selected.match.homeCode}`,
      pick: selected.pick,
      stake: cleanStake,
    };

    setPending((current) => [...current, newBet]);
    setBankroll((current) => Math.round((current - cleanStake) * 100) / 100);
    setSelected(null);
    setStake(Math.max(1, Math.min(5, Math.floor(bankroll - cleanStake))));
    toast.success("Fake bet locked in", { description: `${newBet.pick.label} for ${money(cleanStake)}` });
  }

  function removeBet(bet: Bet) {
    setPending((current) => current.filter((item) => item.id !== bet.id));
    setBankroll((current) => Math.round((current + bet.stake) * 100) / 100);
  }

  function settleSlate() {
    if (!pending.length || settling) return;
    setSettling(true);

    window.setTimeout(() => {
      const oldTierIndex = tierIndex;
      let runningStreak = streak;
      let winsThisRound = 0;
      let payoutTotal = 0;

      const settled = pending.map<Result>((bet) => {
        const impliedChance = Math.max(0.18, Math.min(0.78, 0.94 / bet.pick.odds));
        const betWon = Math.random() < impliedChance;
        const payout = betWon ? Math.round(bet.stake * bet.pick.odds * 100) / 100 : 0;
        payoutTotal += payout;
        if (betWon) {
          winsThisRound += 1;
          runningStreak += 1;
        } else {
          runningStreak = 0;
        }
        return { ...bet, won: betWon, payout };
      });

      const sweepBonus =
        winsThisRound === pending.length && pending.length >= 2
          ? Math.round(payoutTotal * 0.1 * 100) / 100
          : 0;
      const nextBankroll = Math.round((bankroll + payoutTotal + sweepBonus) * 100) / 100;
      const nextHighScore = Math.max(highScore, nextBankroll);
      setBankroll(nextBankroll);
      setHighScore(nextHighScore);
      setWon((current) => current + winsThisRound);
      setPlaced((current) => current + pending.length);
      setStreak(runningStreak);
      setBestStreak((current) => Math.max(current, runningStreak));
      setResults(settled);
      setPending([]);
      setDay((current) => current + 1);
      setSettling(false);
      setChampionDismissed(false);

      const newTierIndex = getTierIndex(nextBankroll);
      if (newTierIndex > oldTierIndex) {
        toast.success(`Lifestyle upgraded: ${tiers[newTierIndex].name}`, {
          description: "Your fake-money climb just leveled up.",
        });
      } else if (winsThisRound === pending.length) {
        toast.success("Perfect slate!", { description: `${winsThisRound} for ${pending.length}. You earned a 10% sweep bonus.` });
      } else if (winsThisRound === 0) {
        toast.error("The slate got you", { description: "Regroup. The comeback is one pick away." });
      } else {
        toast.info("Slate settled", { description: `${winsThisRound} of ${pending.length} bets won.` });
      }
    }, 850);
  }

  function claimRecovery() {
    setBankroll(STARTING_BANKROLL);
    setHighScore((current) => Math.max(current, STARTING_BANKROLL));
    setDay((current) => current + 1);
    setResults([]);
    toast.info("Side-hustle cash collected", { description: "$25 in fake money. Make the comeback count." });
  }

  function resetGame() {
    setBankroll(STARTING_BANKROLL);
    setHighScore(STARTING_BANKROLL);
    setDay(1);
    setStreak(0);
    setBestStreak(0);
    setPlaced(0);
    setWon(0);
    setSelected(null);
    setPending([]);
    setResults([]);
    setChampionDismissed(false);
    localStorage.removeItem(SAVE_KEY);
    toast.info("Fresh run started");
  }

  return (
    <main className="game-shell">
      <Toaster position="top-right" />
      <header className="topbar">
        <div className="brand-lockup" aria-label="Odds Up home">
          <div className="brand-mark"><ArrowUpRight size={24} strokeWidth={3} /></div>
          <div>
            <p className="brand-name">ODDS <span>UP</span></p>
            <p className="brand-kicker">FROM BROKE TO BALLIN&apos;</p>
          </div>
        </div>
        <div className="fake-money-pill"><ShieldCheck size={16} /> SIMULATION · NO REAL MONEY</div>
        <button className="icon-button" onClick={resetGame} aria-label="Reset game" title="Reset game">
          <RotateCcw size={18} />
        </button>
      </header>

      <section className="journey-card" aria-label="Lifestyle progress">
        <div className="journey-backdrop" />
        <div className="journey-scrim" />
        <div className="journey-content">
          <div className="journey-copy">
            <p className="eyebrow">DAY {day} · CURRENT LIFESTYLE</p>
            <h1>{tier.name}</h1>
            <p>{isChampion ? "You made it. The penthouse keys are yours." : `${money(amountToNext)} until ${nextTier.name}`}</p>
          </div>
          <div className="bankroll-card">
            <p><Banknote size={17} /> AVAILABLE BANKROLL</p>
            <strong>{money(bankroll)}</strong>
            <span>Peak {money(highScore)}</span>
          </div>
          <div className="tier-meter">
            <div className="meter-labels">
              <span>{tier.name}</span>
              <span>{isChampion ? "Complete" : nextTier.name}</span>
            </div>
            <Progress value={tierProgress} aria-label={`${Math.round(tierProgress)} percent to next lifestyle`} />
            <div className="tier-dots" aria-hidden="true">
              {tiers.map((item, index) => (
                <span key={item.name} className={index <= tierIndex ? "reached" : ""}>{item.icon}</span>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="stat-strip" aria-label="Career statistics">
        <div><Flame size={19} /><span>WIN STREAK</span><strong>{streak}</strong></div>
        <div><Trophy size={19} /><span>BEST STREAK</span><strong>{bestStreak}</strong></div>
        <div><CircleDollarSign size={19} /><span>WIN RATE</span><strong>{winRate}%</strong></div>
        <div><Crown size={19} /><span>GOAL</span><strong>{money(PENTHOUSE_GOAL)}</strong></div>
      </section>

      <div className="play-grid">
        <section className="board-panel">
          <div className="section-heading">
            <div>
              <p className="eyebrow">TODAY&apos;S BOARD</p>
              <h2>Pick your spots</h2>
            </div>
            <span className="live-chip"><i /> LINES OPEN</span>
          </div>

          <div className="match-list">
            {matches.map((match) => {
              const locked = occupiedMatchIds.has(match.id);
              return (
                <article className={`match-card ${locked ? "locked" : ""}`} key={match.id}>
                  <div className="match-meta">
                    <span>{match.league}</span>
                    <time>{match.clock}</time>
                  </div>
                  <div className="teams-row">
                    <div className="team-pair">
                      <span className="team-code">{match.awayCode}</span>
                      <div><strong>{match.away}</strong><small>AWAY</small></div>
                    </div>
                    <span className="at-symbol">@</span>
                    <div className="team-pair home-team">
                      <span className="team-code">{match.homeCode}</span>
                      <div><strong>{match.home}</strong><small>HOME</small></div>
                    </div>
                  </div>
                  <div className="pick-row">
                    {match.picks.map((pick) => {
                      const active = selected?.match.id === match.id && selected.pick.id === pick.id;
                      return (
                        <button
                          key={pick.id}
                          className={`pick-button ${active ? "active" : ""}`}
                          onClick={() => choosePick(match, pick)}
                          disabled={locked}
                          aria-pressed={active}
                        >
                          <span><small>{pick.sub}</small>{pick.label}</span>
                          <strong>{decimalToAmerican(pick.odds)}</strong>
                        </button>
                      );
                    })}
                  </div>
                  {locked && <div className="locked-label"><ShieldCheck size={15} /> BET LOCKED</div>}
                </article>
              );
            })}
          </div>
        </section>

        <aside className="slip-panel" aria-label="Fake bet slip">
          <div className="slip-header">
            <div><p className="eyebrow">YOUR ACTION</p><h2>Bet slip</h2></div>
            <span>{pending.length}/3</span>
          </div>

          {selected ? (
            <div className="selection-card">
              <div className="selection-top">
                <div><small>{selected.match.league}</small><strong>{selected.pick.label}</strong></div>
                <span>{decimalToAmerican(selected.pick.odds)}</span>
              </div>
              <p>{selected.match.awayCode} @ {selected.match.homeCode} · {selected.pick.sub}</p>
              <label htmlFor="stake">FAKE WAGER</label>
              <div className="stake-input">
                <span>$</span>
                <input
                  id="stake"
                  type="number"
                  min="1"
                  max={Math.max(1, Math.floor(bankroll))}
                  value={stake}
                  onChange={(event) => {
                    const nextStake = Number(event.target.value);
                    setStake(Number.isFinite(nextStake) ? nextStake : 1);
                  }}
                />
              </div>
              <div className="quick-stakes">
                {[5, 10, 25].map((amount) => (
                  <button key={amount} onClick={() => setStake(Math.min(amount, Math.floor(bankroll)))} disabled={bankroll < 1}>${amount}</button>
                ))}
                <button onClick={() => setStake(Math.max(1, Math.floor(bankroll)))}>MAX</button>
              </div>
              <div className="return-row"><span>Possible return</span><strong>{money(possibleReturn)}</strong></div>
              <button className="primary-button" onClick={placeBet} disabled={bankroll < 1 || stake < 1}>
                PLACE FAKE BET <ChevronRight size={18} />
              </button>
            </div>
          ) : (
            <div className="empty-selection">
              <span className="pulse-ring"><ChevronRight size={24} /></span>
              <strong>Choose a line</strong>
              <p>Tap any price on today&apos;s board to build your slip.</p>
            </div>
          )}

          {pending.length > 0 && (
            <div className="pending-list">
              <div className="mini-heading"><span>OPEN BETS</span><strong>{money(pending.reduce((sum, bet) => sum + bet.stake, 0))} risked</strong></div>
              {pending.map((bet) => (
                <div className="pending-bet" key={bet.id}>
                  <div><strong>{bet.pick.label}</strong><span>{bet.matchup} · {money(bet.stake)}</span></div>
                  <button onClick={() => removeBet(bet)} aria-label={`Remove ${bet.pick.label} bet`}>×</button>
                </div>
              ))}
              <button className="settle-button" onClick={settleSlate} disabled={settling}>
                {settling ? <><span className="spinner" /> GAMES IN PROGRESS…</> : <>SIMULATE GAMES <ArrowUpRight size={18} /></>}
              </button>
            </div>
          )}

          {!pending.length && bankroll < 5 && (
            <div className="recovery-card">
              <p>BANKROLL BUSTED?</p>
              <strong>The comeback starts with a side hustle.</strong>
              <button onClick={claimRecovery}>COLLECT $25 FAKE CASH</button>
            </div>
          )}

          {results.length > 0 && !pending.length && (
            <div className="results-panel">
              <div className="mini-heading"><span>LAST SLATE</span><strong>Day {day - 1}</strong></div>
              {results.map((result) => (
                <div className={`result-row ${result.won ? "win" : "loss"}`} key={result.id}>
                  <span>{result.won ? "W" : "L"}</span>
                  <div><strong>{result.pick.label}</strong><small>{result.matchup}</small></div>
                  <b>{result.won ? `+${money(result.payout - result.stake)}` : `-${money(result.stake)}`}</b>
                </div>
              ))}
            </div>
          )}
        </aside>
      </div>

      <footer>
        <p>ODDS UP is a fictional game using fake currency. No real wagering, deposits, or prizes.</p>
        <span>BET SMART · STAY FAKE</span>
      </footer>

      {isChampion && !championDismissed && (
        <div className="win-overlay" role="dialog" aria-modal="true" aria-labelledby="win-title">
          <div className="win-card">
            <span className="crown-orbit"><Crown size={40} /></span>
            <p className="eyebrow">THE KEYS ARE YOURS</p>
            <h2 id="win-title">Penthouse unlocked.</h2>
            <p>You turned {money(STARTING_BANKROLL)} in fake money into {money(bankroll)}. Keep running it up—or start a fresh climb.</p>
            <div className="win-actions">
              <button onClick={() => setChampionDismissed(true)}>KEEP PLAYING</button>
              <button onClick={resetGame}>NEW RUN</button>
            </div>
          </div>
        </div>
      )}
    </main>
  );
}
