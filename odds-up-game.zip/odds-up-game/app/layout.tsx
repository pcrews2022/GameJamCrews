import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "ODDS UP — Fake Money Sports Betting Game",
  description: "Turn a $25 fake bankroll into a $15,000 penthouse in this sports betting progression game.",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
